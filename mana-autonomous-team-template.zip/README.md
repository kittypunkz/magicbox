# 🌅 Mana's Autonomous Team Template

Deploy a full autonomous development team to any project in minutes.

## What's Included

### Team Members

| Name | Role | Meaning | Does |
|------|------|---------|------|
| **Mana** | Product Owner | Make determined effort | Plans, delegates, decides |
| **Rupa** | Architect | Form, structure | Designs systems |
| **Kaji** | Developer | Build, construct | Writes code |
| **Vera** | QA | Truth, verification | Tests, validates |
| **Arun** | DevOps | Dawn, new beginning | Deploys, automates |

### Files Structure

```
.kimi/
├── pipeline/
│   └── DEPLOYMENT.md          # Deployment workflow
├── skills/
│   ├── architect/SKILL.md     # Rupa's responsibilities
│   ├── developer/SKILL.md     # Kaji's responsibilities
│   ├── qa/SKILL.md            # Vera's responsibilities
│   └── devops/SKILL.md        # Arun's responsibilities
├── docs/
│   ├── TEAM_MANIFEST.md       # Team identities & flow
│   └── TEAM_SETUP_GUIDE.md    # Full setup instructions
└── template/                  # Quick start templates
    ├── AGENTS.md
    └── SETUP_CHECKLIST.md

AGENTS.md                       # Root team reference (copy to project root)
```

## Quick Setup

### Step 1: Extract
Extract this zip to your project root.

### Step 2: Update (Optional)
Edit skill files to match your tech stack:
- `.kimi/skills/developer/SKILL.md` - Your frontend/backend stack
- `.kimi/skills/devops/SKILL.md` - Your deployment target
- `.kimi/skills/architect/SKILL.md` - Your architecture patterns

### Step 3: Initialize
Tell Mana:
> "Initialize team for this project"

Mana will:
1. Read your codebase
2. Brief the team
3. Establish workflow
4. Report back ready

## How to Use

Once initialized, just talk to Mana:

```
"Mana, plan the authentication feature"
→ Rupa designs → Kaji builds → Vera tests

"Mana, fix bug #123"
→ Kaji fixes → Vera verifies

"Mana, deploy to production"
→ Arun deploys → Vera smoke tests
```

## Documentation

- **Full Setup Guide:** `.kimi/docs/TEAM_SETUP_GUIDE.md`
- **Team Manifest:** `.kimi/docs/TEAM_MANIFEST.md`
- **Deployment Flow:** `.kimi/pipeline/DEPLOYMENT.md`

---

*Every project is a new dawn 🌅*
